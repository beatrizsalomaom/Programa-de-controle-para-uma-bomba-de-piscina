/*
 * File:   interrup��o.c
 * Author: salom
 *
 * Created on 9 de Dezembro de 2020, 15:15
 */


#include "bits.h"
#include <pic18f4520.h>

void Interrupcao(void) interrupt 1 {
    char i, j;
    if (bitTst(INTCON, 0)) { //PORTA B : mudou valor
        for (i = 0; i < 4; i++) {
            PORTB |= 0xFF;
            bitClr(PORTB, (i));
            for (j = 0; j < 10; j++);
            for (j = 0; j < 4; j++) {
                if (!bitTst(PORTB, j + 4)) {
                    bitSet(Tecla, (i * 4) + j);
                } else {
                    bitClr(Tecla, (i * 4) + j);
                }

            }

        }
        PORTB = 0x00;
        bitClr(INTCON, 0);

    }

    return;
}
